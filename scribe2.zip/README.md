# adept_scribe_tool
ADEPT SCRIBE TOOL
