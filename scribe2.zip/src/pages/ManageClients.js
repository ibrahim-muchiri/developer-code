import React, { useState, useContext,  useEffect } from "react";
import adminLayout from "../hoc/adminLayout"
import axios from "axios";

function ManageClients() {
    const [clients, setClients] = useState([]);
  
    useEffect(() => {
      const fetchData = async () => {
        const response = await fetch('https://scribe.clickaway.co.ke/api/clients', {
          headers: {
            'accept': 'application/json',
            'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZXN0QHRlc3QuY29tIiwiY2xhaW1zIjpbIlJFQURfUFJJVklMRUdFIiwiUk9MRV9BRE1JTiIsIldSSVRFX1BSSVZJTEVHRSJdLCJleHAiOjE2NzY0NDUwMDZ9.O0yi35hCBkrT3zbg617RVuoQtWoreivOiH6aItNECeXiT6E8aChMzUboyozWkxE54c0yt7ZZMg8LNSE-eTLdAQ'
          }
        });
        const data = await response.json();
        setClients(data);
      };
      fetchData();
    }, []);
  
    return (
      <div>
        <h1>Clients</h1>
        <ul>
          {clients.map(client => (
            <li key={client.clientId}>{client.clientName}</li>
          ))}
        </ul>
      </div>
    );
  }
  
  export default adminLayout(ManageClients);
