import React, { useState } from "react";
import adminLayout from "../hoc/adminLayout";
import DataTable from 'react-data-table-component';

import 'react-dropdown/style.css';

  
const columns = [
  {
    name: 'Job',
    selector: 'job',
    sortable: true,
    filterable: true
  },{
    name: 'Status',
    selector: 'status',
    sortable: true,
    filterable: true
  },
  {
    name: 'Actions',
    selector: 'actions',
    cell: (row) => (
        <div className="dropdown table-action-dropdown">
        <button className="btn btn-secondary btn-sm dropdown-toggle" type="button" id="dropdownMenuButtonSM" data-bs-toggle="dropdown" aria-expanded="false"><i className="fa fa-ellipsis-v" aria-hidden="true"></i></button>
        <ul className="dropdown-menu" aria-labelledby="dropdownMenuButtonSM">
        <li><a className="dropdown-item" href={`/task?${row.id}`}><i className="fa fa-pencil" aria-hidden="true"></i> Transcribe Job </a></li>
        <div className="dropdown-divider"></div>
        <li><a className="dropdown-item " href={`/task?${row.id}`}><i className="fa fa-info" aria-hidden="true"></i> Review job</a></li>
     
       
        </ul>
        </div>
        )
},
];

const data = [
  {
    id: 1,
    job: 'Job 1',
    status: 'PENDING'
    
  },
  {
    id: 2,
    job: 'Job 2',
    status: 'COMPLETE'
  },
  {
    id: 3,
    job: 'Job 3',
    status: 'PENDING'
    
  },
  {
    id: 4,
    job: 'Job 4',
    status: 'PENDING'
    
  },
  {
    id: 5,
    job: 'Job 5',
    status: 'COMPELETE'
    
  },
  {
    id: 6,
    job: 'Job 6',
    status: 'COMPELETE'
    
  },
  {
    id: 7,
    job: 'Job 7',
    status: 'COMPELETE'
    
  },{
    id: 8,
    job: 'Job 8',
    status: 'COMPELETE'
    
  },
  {
    id: 9,
    job: 'Job 9',
    status: 'COMPELETE'
    
  },
  {
    id: 10,
    job: 'Job 10',
    status: 'COMPELETE'
    
  }
  
];

function ViewJobs() {
  const [filterText, setFilterText] = useState('');
  const filteredData = data.filter(
    item => item.job.toLowerCase().includes(filterText.toLowerCase())
  );

  return (
    <>
   
      <DataTable
        title={<div style={{}}><div>JOBS </div> <div style={{ display: "flex", justifyContent: "flex-end" }}><input type="text"  placeholder="Filter by job title"   value={filterText} onChange={e => setFilterText(e.target.value)} /></div> </div>}
        columns={columns}
        data={filteredData}
        pagination
        paginationPerPage={10}
      />
    </>
  );
};

export default adminLayout(ViewJobs);
